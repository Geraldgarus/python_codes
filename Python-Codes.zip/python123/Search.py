 class node:
    def __init__(self,data):
        self.data = data
        self.next = None
class linkedlist:
    def __init__(self):
       self.head = None
       
    def append(self,data):
        newnode = node(data)
        if self.head is None:
            self.head = newnode
            self.tail = newnode
            
            return
        self.tail.next = newnode
        self.tail = newnode

        
    def search(self,key):
        cur = self.head
        index = 0
        while cur is not None:
             if cur.data == key:
                  return index
             cur = cur.next
             index +=1
        return -1
        
             
             
 
    def printlinkedlist(self):
        while self.head is not None:
             print (self.head.data, end ="--->")
             self.head = self.head.next
        print("Null")
             
            
linkedlist = linkedlist()

linkedlist.append(5)
linkedlist.append(6)
linkedlist.append(7)
linkedlist.append(10)
linkedlist.search(10)
linkedlist.printlinkedlist()




search = linkedlist.search(7)

if search != -1:
    print("Element 10 found at index:",search)
else:
    print("Element 10 not found in the linked list")
