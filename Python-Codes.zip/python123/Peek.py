class stack:
     def __init__(self):
          self.top = None 
          self.count = 0
          self.maxsize = 5
          
    
     def push(self,data):
          tempnode = node(data)
          tempnode.next = self.top
          self.top = tempnode
          self.count += 1
     def peek(self):
         if self.top is not None:
             return self.top.data
         else:
             return None
             
     def printstack(self):
         while self.top is not None:
              print (self.top.data)
              self.top = self.top.next
    
     
             
stack = stack()
stack.push(2)
stack.push(7)
stack.peek()
print (" the top element is:",stack.top.data)
stack.printstack()