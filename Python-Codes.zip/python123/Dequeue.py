
class queue:
    def __init__(self):
       self.front = None
       self.count = 0
       
   
    def dequeue(self):
        if self.front is None:
            return None
        else:
            toreturn = self.front.data
            self.front = self.front.next
            return toreturn
    def printqueue(self):
        while self.front is not None:
            print(self.front.data)
            self.front = self.front.next

                 
queue = queue()
queue = dequeue()
queue.printqueue()
