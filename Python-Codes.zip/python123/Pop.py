class stack:
     def __init__(self):
          self.top = None 
          self.count = 0
          self.maxsize = 5
          
    
     def push(self,data):
          tempnode = node(data)
          tempnode.next = self.top
          self.top = tempnode
          self.count += 1
    
             
     def pop(self,data):
         if self.top is None:
              return None
         else:
             toreturn = self.top.data
             self.top = self.top.next
             return toreturn
             self.count -= 1
             
   
     def printstack(self):
         while self.top is not None:
              print (self.top.data)
              self.top = self.top.next
 
     
             
stack = stack()
stack.push(2)
stack.push(7)
stack.pop()
stack.printstack()