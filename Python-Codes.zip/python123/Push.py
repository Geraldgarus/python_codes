class stack:
    def __init__ (self):
        self.top = None
        
    def push(self,data):
        newnode = node(data)
        if self.top is None:
             self.top = newnode
             
        else:
            newnode.next = self.top
            self.top = newnode
    
stack = stack ()
stack.push(3)
stack.push(4)
stack.push(87)
stack.push(65)
print (stack.top.data)
