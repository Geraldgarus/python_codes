: class node:
    def __init__(self,data):
         self.data = data
         self.next = None
         
class linkedlist:
    def __init__(self):
         self.head = None
      
         
    def append(self,data):
         newnode = node(data)
         if self.head is None:
              self.head = newnode
              self.tail = newnode
              return
         newnode.next = self.tail
         self.tail = newnode
         
    def insertbetween(self,data,node1,node2):
         newnode = node(data)
         if self.head is None:
              self.head = newnode
              return
         cur = self.head
         while cur:
              if cur.data == node1 and cur.next.data == node2:
                   newnode.next = cur.next
                   cur.next = newnode
                   break
              cur = cur.next
    def llist(self):
          while self.head is not None:
               print(self.head.data,end = "---->")
               self.head = self.head.next
          print(" Null ")
          
ll = linkedlist()
ll.prepend(" wed")
ll.prepend("mond")
ll.insertbetween("tue", "mon", " wed")
ll.llist()